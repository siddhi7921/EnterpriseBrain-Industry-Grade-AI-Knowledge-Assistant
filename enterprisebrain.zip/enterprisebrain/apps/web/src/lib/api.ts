import type {
  AnalyticsOverview,
  AuditLogItem,
  ChatResponse,
  ConversationDetail,
  ConversationSummary,
  DocumentResponse,
  EvaluationRunResponse,
  MemberResponse,
  OrganizationResponse,
  TokenResponse,
  UserResponse,
} from "../types/api";

const API_BASE = import.meta.env.VITE_API_BASE_URL || "http://localhost:8000/api/v1";

function getAccessToken(): string | null {
  return localStorage.getItem("eb_access_token");
}

async function request<T>(path: string, options: RequestInit = {}): Promise<T> {
  const token = getAccessToken();
  const headers = new Headers(options.headers || {});
  if (token) {
    headers.set("Authorization", `Bearer ${token}`);
  }
  if (!(options.body instanceof FormData) && !headers.has("Content-Type")) {
    headers.set("Content-Type", "application/json");
  }

  const res = await fetch(`${API_BASE}${path}`, {
    ...options,
    headers,
  });

  if (res.status === 204) {
    return undefined as T;
  }

  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(data.detail || `Request failed with status ${res.status}`);
  }
  return data as T;
}

export const api = {
  // Auth
  register: (email: string, password: string, organization_name?: string) =>
    request<TokenResponse>("/auth/register", {
      method: "POST",
      body: JSON.stringify({ email, password, organization_name: organization_name || null }),
    }),

  login: (email: string, password: string) =>
    request<TokenResponse>("/auth/login", {
      method: "POST",
      body: JSON.stringify({ email, password }),
    }),

  me: () => request<UserResponse>("/auth/me"),

  // Organisations
  listOrganizations: () => request<OrganizationResponse[]>("/organizations"),

  createOrganization: (name: string) =>
    request<OrganizationResponse>("/organizations", {
      method: "POST",
      body: JSON.stringify({ name }),
    }),

  listMembers: (orgId: string) => request<MemberResponse[]>(`/organizations/${orgId}/members`),

  addMember: (orgId: string, email: string, role: "owner" | "admin" | "member") =>
    request<MemberResponse>(`/organizations/${orgId}/members`, {
      method: "POST",
      body: JSON.stringify({ email, role }),
    }),

  updateMemberRole: (orgId: string, userId: string, role: "owner" | "admin" | "member") =>
    request<MemberResponse>(`/organizations/${orgId}/members/${userId}`, {
      method: "PATCH",
      body: JSON.stringify({ role }),
    }),

  // Documents
  listDocuments: (orgId: string) => request<DocumentResponse[]>(`/organizations/${orgId}/documents`),

  uploadDocument: (orgId: string, file: File, accessScope: "organization" | "restricted") => {
    const form = new FormData();
    form.append("file", file);
    form.append("access_scope", accessScope);
    return request<DocumentResponse>(`/organizations/${orgId}/documents`, {
      method: "POST",
      body: form,
    });
  },

  reindexDocument: (docId: string) =>
    request(`/documents/${docId}/reindex`, { method: "POST" }),

  deleteDocument: (docId: string) =>
    request<void>(`/documents/${docId}`, { method: "DELETE" }),

  updateDocumentPermissions: (
    docId: string,
    access_scope: "organization" | "restricted",
    permissions: { user_id: string; permission: "read" | "manage" }[]
  ) =>
    request<DocumentResponse>(`/documents/${docId}/permissions`, {
      method: "PATCH",
      body: JSON.stringify({ access_scope, permissions }),
    }),

  // Chat & RAG
  sendChat: (
    orgId: string,
    payload: {
      conversation_id: string | null;
      question: string;
      filters: { document_ids: string[] };
      top_k: number;
      retrieval_mode: "vector" | "keyword" | "hybrid" | "hybrid_rerank";
    }
  ) =>
    request<ChatResponse>(`/organizations/${orgId}/chat`, {
      method: "POST",
      body: JSON.stringify(payload),
    }),

  listConversations: (orgId: string) =>
    request<ConversationSummary[]>(`/conversations?organization_id=${orgId}`),

  getConversation: (conversationId: string) =>
    request<ConversationDetail>(`/conversations/${conversationId}`),

  deleteConversation: (conversationId: string) =>
    request<void>(`/conversations/${conversationId}`, { method: "DELETE" }),

  submitFeedback: (messageId: string, rating: number, comment?: string) =>
    request(`/messages/${messageId}/feedback`, {
      method: "POST",
      body: JSON.stringify({ rating, comment: comment || null }),
    }),

  // Analytics & Evaluation
  getAnalytics: (orgId: string) => request<AnalyticsOverview>(`/organizations/${orgId}/analytics`),

  getAuditLogs: (orgId: string) => request<AuditLogItem[]>(`/organizations/${orgId}/audit-logs`),

  runEvaluation: (orgId: string, dataset_name = "enterprise_qa_benchmark", top_k = 5) =>
    request<EvaluationRunResponse>("/admin/evaluations/run", {
      method: "POST",
      body: JSON.stringify({ organization_id: orgId, dataset_name, top_k }),
    }),

  listEvaluations: (orgId: string) =>
    request<EvaluationRunResponse[]>(`/admin/evaluations?organization_id=${orgId}`),
};
